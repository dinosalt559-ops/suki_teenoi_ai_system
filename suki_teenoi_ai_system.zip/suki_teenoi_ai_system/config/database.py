from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# ตั้งค่า URL สำหรับเชื่อมต่อ MySQL (ปรับ user, password, host, port, db_name ตามจริง)
DATABASE_URL = "mysql+pymysql://root:@localhost:3306/suki_teenoi_db?charset=utf8mb4"

engine = create_engine(
    DATABASE_URL,
    pool_size=10,
    max_overflow=20,
    pool_recycle=3600,
    pool_pre_ping=True
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()