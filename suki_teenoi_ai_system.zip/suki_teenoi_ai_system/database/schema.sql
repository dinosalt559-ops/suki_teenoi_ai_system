-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2026 at 03:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schema`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` varchar(20) NOT NULL,
  `branch_name` varchar(100) NOT NULL,
  `location_type` enum('Mall','Standalone','University') NOT NULL,
  `manager_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contextual_factors`
--

CREATE TABLE `contextual_factors` (
  `factor_date` date NOT NULL,
  `is_weekend` tinyint(1) NOT NULL DEFAULT 0,
  `is_public_holiday` tinyint(1) NOT NULL DEFAULT 0,
  `is_payday_season` tinyint(1) NOT NULL DEFAULT 0,
  `rainfall_mm` decimal(5,2) DEFAULT 0.00,
  `nearby_major_event` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `daily_sales_forecasts`
--

CREATE TABLE `daily_sales_forecasts` (
  `log_date` date NOT NULL,
  `branch_id` varchar(20) NOT NULL,
  `ai_predicted_customers` int(11) DEFAULT NULL,
  `actual_customers` int(11) DEFAULT NULL,
  `actual_queues` int(11) DEFAULT NULL,
  `peak_hour_customers` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_items`
--

CREATE TABLE `inventory_items` (
  `item_id` varchar(50) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `unit` varchar(20) DEFAULT 'kg',
  `portion_per_customer_kg` decimal(5,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_transactions`
--

CREATE TABLE `inventory_transactions` (
  `transaction_id` int(11) NOT NULL,
  `log_date` date NOT NULL,
  `branch_id` varchar(20) NOT NULL,
  `item_id` varchar(50) NOT NULL,
  `opening_stock_kg` decimal(10,2) NOT NULL,
  `ai_suggested_order_kg` decimal(10,2) NOT NULL,
  `manager_approved_order_kg` decimal(10,2) DEFAULT NULL,
  `po_status` enum('Pending','Approved','Delivered') DEFAULT 'Pending',
  `used_stock_kg` decimal(10,2) DEFAULT NULL,
  `food_waste_kg` decimal(10,2) DEFAULT NULL,
  `ending_stock_kg` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `contextual_factors`
--
ALTER TABLE `contextual_factors`
  ADD PRIMARY KEY (`factor_date`);

--
-- Indexes for table `daily_sales_forecasts`
--
ALTER TABLE `daily_sales_forecasts`
  ADD PRIMARY KEY (`log_date`,`branch_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `inventory_items`
--
ALTER TABLE `inventory_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD UNIQUE KEY `unique_daily_log` (`log_date`,`branch_id`,`item_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `item_id` (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `daily_sales_forecasts`
--
ALTER TABLE `daily_sales_forecasts`
  ADD CONSTRAINT `daily_sales_forecasts_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `daily_sales_forecasts_ibfk_2` FOREIGN KEY (`log_date`) REFERENCES `contextual_factors` (`factor_date`);

--
-- Constraints for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  ADD CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`item_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
