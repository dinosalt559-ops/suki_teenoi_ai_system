import os
import joblib
import pandas as pd
import numpy as np
from lightgbm import LGBMRegressor
from sklearn.preprocessing import StandardScaler

class DemandForecastModel:
    def __init__(self, model_dir: str = "ml_core/saved_models"):
        self.model_dir = model_dir
        self.model_path = os.path.join(model_dir, "lgbm_model.pkl")
        self.scaler_path = os.path.join(model_dir, "scaler.pkl")
        
        self.feature_columns = [
            'day_of_week', 'month', 'is_weekend', 
            'is_public_holiday', 'is_payday_season', 
            'rainfall_mm', 'nearby_major_event'
        ]
        
        self.scaler = StandardScaler()
        self.model = LGBMRegressor(
            n_estimators=150,
            learning_rate=0.03,
            max_depth=6,
            random_state=42
        )
        
        os.makedirs(self.model_dir, exist_ok=True)

    def prepare_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """แปลงข้อมูลจากตาราง contextual_factors ให้พร้อมใช้งาน"""
        data = df.copy()
        date_col = 'factor_date' if 'factor_date' in data.columns else 'log_date'
        data['date_dt'] = pd.to_datetime(data[date_col])
        
        data['day_of_week'] = data['date_dt'].dt.dayofweek
        data['month'] = data['date_dt'].dt.month
        
        bool_cols = ['is_weekend', 'is_public_holiday', 'is_payday_season', 'nearby_major_event']
        for col in bool_cols:
            if col in data.columns:
                data[col] = data[col].astype(int)
                
        return data

    def train_and_save(self, df_context: pd.DataFrame, target_series: pd.Series):
        """เทรนโมเดลและบันทึกไฟล์ไว้ใช้งาน"""
        df_featured = self.prepare_features(df_context)
        X = df_featured[self.feature_columns].values
        
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, target_series)
        
        joblib.dump(self.model, self.model_path)
        joblib.dump(self.scaler, self.scaler_path)
        print("✓ บันทึกโมเดล LightGBM และ Scaler เรียบร้อยแล้ว")

    def predict_next_day(self, today_context_df: pd.DataFrame) -> int:
        """พยากรณ์จำนวนลูกค้าสำหรับข้อมูลปัจจัยแวดล้อม 1 วัน"""
        if not os.path.exists(self.model_path):
            raise FileNotFoundError("ไม่พบไฟล์โมเดล กรุณาเทรนโมเดลก่อนใช้งาน")
            
        loaded_model = joblib.load(self.model_path)
        loaded_scaler = joblib.load(self.scaler_path)
        
        df_featured = self.prepare_features(today_context_df)
        X = df_featured[self.feature_columns].values
        X_scaled = loaded_scaler.transform(X)
        
        prediction = loaded_model.predict(X_scaled)[0]
        return int(max(0, round(prediction)))