import math
import numpy as np

class AdvancedInventoryEngine:
    def __init__(self, service_level_z: float = 1.65):
        # ค่า Z-Score 1.65 คือระดับความปลอดภัยสต็อกที่ 95%
        self.z_score = service_level_z

    def compute_item_order(
        self,
        predicted_customers: int,
        current_stock_kg: float,
        historical_daily_customers: list,
        item_data: dict
    ) -> dict:
        """
        คำนวณคำสั่งซื้อและงบประมาณสำหรับวัตถุดิบ 1 รายการ
        item_data รองรับฟิลด์จากตาราง inventory_items
        """
        item_id = item_data["item_id"]
        item_name = item_data["item_name"]
        unit_cost = float(item_data["unit_cost_thb"])
        portion_per_head = float(item_data.get("portion_per_customer_kg", 0.15))
        ordering_cost = float(item_data.get("ordering_cost_s", 500.0))
        holding_cost = float(item_data.get("annual_holding_cost_h", 15.0))
        lead_time = int(item_data.get("lead_time_days", 1))

        # 1. คำนวณความต้องการย้อนหลังและค่าเบี่ยงเบน
        daily_demands = np.array(historical_daily_customers) * portion_per_head
        mean_demand = float(np.mean(daily_demands)) if len(daily_demands) > 0 else 0.0
        std_demand = float(np.std(daily_demands)) if len(daily_demands) > 0 else 0.0
        annual_demand = mean_demand * 365.0

        # 2. คำนวณ Safety Stock (SS) และ Reorder Point (ROP)
        safety_stock = self.z_score * std_demand * math.sqrt(lead_time)
        rop = (mean_demand * lead_time) + safety_stock

        # 3. คำนวณ Economic Order Quantity (EOQ)
        eoq = math.sqrt((2 * annual_demand * ordering_cost) / holding_cost) if holding_cost > 0 else 0.0

        # 4. ตรวจสอบเงื่อนไขการสั่งซื้อและคำนวณงบประมาณ
        expected_usage = predicted_customers * portion_per_head
        
        if current_stock_kg <= rop:
            net_need = (expected_usage + safety_stock) - current_stock_kg
            suggested_order_kg = float(math.ceil(max(net_need, eoq)))
            order_triggered = True
        else:
            suggested_order_kg = 0.0
            order_triggered = False

        required_budget = round(suggested_order_kg * unit_cost, 2)

        return {
            "item_id": item_id,
            "item_name": item_name,
            "current_stock_kg": round(current_stock_kg, 2),
            "reorder_point_rop_kg": round(rop, 2),
            "safety_stock_kg": round(safety_stock, 2),
            "eoq_kg": round(eoq, 2),
            "order_triggered": order_triggered,
            "suggested_order_kg": suggested_order_kg,
            "unit_cost_thb": unit_cost,
            "required_budget_thb": required_budget
        }